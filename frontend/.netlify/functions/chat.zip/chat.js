// Gelişmiş Akıllı Yanıt Motoru - OstWindGroup AI
const IntelligentResponseEngine = require('./intelligent-engine');

exports.handler = async (event, context) => {
  console.log('=== OSTWINDGROUP AI CHAT FUNCTION ===');
  console.log('Method:', event.httpMethod);
  console.log('Body:', event.body);
  
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  try {
    const body = JSON.parse(event.body);
    const { conversation_id, message } = body;
    
    console.log('Message:', message);
    
    if (!message || !message.trim()) {
      return { 
        statusCode: 400, 
        headers, 
        body: JSON.stringify({ error: 'Message is required' }) 
      };
    }

    // OpenAI API entegrasyonu
    const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
    let aiResponse = '';
    const lowerCaseMessage = message.toLowerCase();

    // Önce OpenAI ile deneyelim
    if (OPENAI_API_KEY) {
      try {
        console.log('🤖 OpenAI API ile yanıt oluşturuluyor...');
        
        const openaiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${OPENAI_API_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            model: 'gpt-4o-mini',
            messages: [
              {
                role: 'system',
                content: `Sen OstWindGroup AI asistanısın. Ukrayna üniversiteleri konusunda uzman bir asistansın. 

                Özellikle şu üniversiteler hakkında detaylı bilgi verebilirsin:
                - Karazin adına Xarkov Milli Universiteti
                - Milli texniki universitet "Xarkov Politexnik institutu" (ХПІ)
                - Milli Aerokosmik Universiteti (ХАІ)
                - Ukrayna Dövlət Biotexnologiya Universiteti
                - Xarkov Milli Tibb Universiteti (ХНМУ)
                - Dövlət mülki müdafiə universiteti (МЧС)
                
                Her üniversite için fakültələr, təhsil haqları, şərtlər hakkında detaylı bilgi verebilirsin.
                Türkçe yanıt ver ve profesyonel bir ton kullan.
                
                Eğer kullanıcı spesifik bir üniversite sorarsa (örneğin "biotexnologiya universitesi fakulteler"), o üniversitenin detaylı fakültə listesini ve təhsil haqlarını ver.
                
                Eğer genel sorular sorarsa (örneğin "ukrayna universiteleri fiyat"), tüm üniversitelerin təhsil haqlarını karşılaştırmalı olarak ver.
                
                Eğer programlama veya teknik konular sorarsa, detaylı açıklamalar ver.`
              },
              {
                role: 'user',
                content: message
              }
            ],
            max_tokens: 2000,
            temperature: 0.7
          })
        });

        if (openaiResponse.ok) {
          const openaiData = await openaiResponse.json();
          aiResponse = openaiData.choices[0].message.content;
          console.log('✅ OpenAI API başarılı yanıt:', aiResponse.substring(0, 100) + '...');
        } else {
          console.log('❌ OpenAI API hatası:', openaiResponse.status);
          throw new Error('OpenAI API hatası');
        }
      } catch (error) {
        console.log('⚠️ OpenAI API hatası, akıllı fallback kullanılıyor:', error.message);
        // OpenAI başarısız olursa akıllı fallback kullan
        const engine = new IntelligentResponseEngine();
        aiResponse = engine.generateResponse(message, conversation_id);
      }
    } else {
      console.log('⚠️ OpenAI API anahtarı bulunamadı, akıllı fallback kullanılıyor');
      // API anahtarı yoksa akıllı fallback kullan
      const engine = new IntelligentResponseEngine();
      aiResponse = engine.generateResponse(message, conversation_id);
    }

    // Eğer hala yanıt yoksa, akıllı fallback kullan
    if (!aiResponse) {
      console.log('⚠️ Yanıt oluşturulamadı, akıllı fallback kullanılıyor');
      const engine = new IntelligentResponseEngine();
      aiResponse = engine.generateResponse(message, conversation_id);
    }

    console.log('📤 Sending response:', aiResponse.substring(0, 100) + '...');
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        conversation_id: conversation_id || 'new',
        message: aiResponse,
        timestamp: new Date().toISOString(),
        isOpenAISuccess: !!OPENAI_API_KEY,
        systemType: OPENAI_API_KEY ? 'openai' : 'intelligent-fallback'
      }),
    };

  } catch (error) {
    console.error('🔴 Function error:', error);
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        conversation_id: 'error',
        message: 'Üzgünüm, bir hata oluştu. Lütfen tekrar deneyin.',
        timestamp: new Date().toISOString(),
        error: error.message
      }),
    };
  }
};