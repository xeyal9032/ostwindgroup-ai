exports.handler = async (event, context) => {
  console.log('=== DEBUG FUNCTION ===');
  
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const apiKey = process.env.GOOGLE_AI_API_KEY;
    console.log('API Key Length:', apiKey ? apiKey.length : 'NOT SET');
    console.log('API Key First 10 chars:', apiKey ? apiKey.substring(0, 10) : 'NOT SET');
    console.log('API Key Last 10 chars:', apiKey ? apiKey.substring(apiKey.length - 10) : 'NOT SET');
    
    // Test Google AI import
    let googleAIStatus = 'NOT_LOADED';
    let googleAIError = null;
    
    try {
      const { GoogleGenerativeAI } = require('@google/generative-ai');
      googleAIStatus = 'LOADED_SUCCESSFULLY';
      console.log('✅ Google AI package loaded successfully');
      
      // Test actual API call
      if (apiKey) {
        try {
          const genAI = new GoogleGenerativeAI(apiKey);
          const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
          
          const result = await model.generateContent('Test mesajı');
          const response = await result.response;
          const text = response.text();
          
          googleAIStatus = 'API_CALL_SUCCESSFUL';
          console.log('✅ Google AI API call successful:', text);
          
        } catch (apiError) {
          googleAIStatus = 'API_CALL_FAILED';
          googleAIError = apiError.message;
          console.error('❌ Google AI API call failed:', apiError);
        }
      } else {
        googleAIStatus = 'NO_API_KEY';
      }
      
    } catch (importError) {
      googleAIStatus = 'IMPORT_ERROR';
      googleAIError = importError.message;
      console.error('❌ Google AI import error:', importError);
    }
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        message: 'Debug bilgileri',
        apiKeyLength: apiKey ? apiKey.length : 0,
        apiKeyPreview: apiKey ? `${apiKey.substring(0, 10)}...${apiKey.substring(apiKey.length - 10)}` : 'NOT SET',
        googleAIStatus: googleAIStatus,
        googleAIError: googleAIError,
        timestamp: new Date().toISOString()
      }),
    };

  } catch (error) {
    console.error('Debug function error:', error);
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        message: 'Debug function error',
        error: error.message,
        timestamp: new Date().toISOString()
      }),
    };
  }
};
