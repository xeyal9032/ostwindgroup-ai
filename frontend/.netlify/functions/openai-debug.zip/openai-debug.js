exports.handler = async (event, context) => {
  console.log('=== OPENAI DEBUG FUNCTION ===');
  
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
    
    console.log('OpenAI API Key Length:', OPENAI_API_KEY ? OPENAI_API_KEY.length : 'NOT_FOUND');
    console.log('OpenAI API Key Preview:', OPENAI_API_KEY ? OPENAI_API_KEY.substring(0, 10) + '...' : 'NOT_FOUND');
    
    if (!OPENAI_API_KEY) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          message: 'OpenAI API Key bulunamadı',
          openaiStatus: 'API_KEY_NOT_FOUND',
          environment: process.env
        })
      };
    }

    // OpenAI API test
    try {
      console.log('OpenAI API test başlatılıyor...');
      
      const openaiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${OPENAI_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'gpt-4o-mini',
          messages: [
            {
              role: 'user',
              content: 'Merhaba, test mesajı'
            }
          ],
          max_tokens: 50
        })
      });

      console.log('OpenAI Response Status:', openaiResponse.status);
      
      if (openaiResponse.ok) {
        const openaiData = await openaiResponse.json();
        console.log('OpenAI Response Data:', openaiData);
        
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({
            message: 'OpenAI API başarılı',
            openaiStatus: 'SUCCESS',
            response: openaiData.choices[0].message.content,
            apiKeyLength: OPENAI_API_KEY.length,
            apiKeyPreview: OPENAI_API_KEY.substring(0, 10) + '...'
          })
        };
      } else {
        const errorText = await openaiResponse.text();
        console.log('OpenAI Error Response:', errorText);
        
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({
            message: 'OpenAI API hatası',
            openaiStatus: 'API_CALL_FAILED',
            error: errorText,
            status: openaiResponse.status,
            apiKeyLength: OPENAI_API_KEY.length,
            apiKeyPreview: OPENAI_API_KEY.substring(0, 10) + '...'
          })
        };
      }
    } catch (error) {
      console.log('OpenAI API Exception:', error.message);
      
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          message: 'OpenAI API exception',
          openaiStatus: 'EXCEPTION',
          error: error.message,
          apiKeyLength: OPENAI_API_KEY.length,
          apiKeyPreview: OPENAI_API_KEY.substring(0, 10) + '...'
        })
      };
    }

  } catch (error) {
    console.error('Debug function error:', error);
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        message: 'Debug function hatası',
        error: error.message
      })
    };
  }
};
