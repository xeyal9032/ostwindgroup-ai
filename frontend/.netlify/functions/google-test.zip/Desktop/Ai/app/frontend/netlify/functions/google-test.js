const fetch = require('node-fetch');

exports.handler = async (event, context) => {
  console.log('=== GOOGLE AI DIRECT TEST WITH NODE-FETCH ===');
  
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const apiKey = process.env.GOOGLE_AI_API_KEY;
    console.log('API Key Length:', apiKey ? apiKey.length : 'NOT SET');
    
    if (!apiKey) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          message: 'API key not set',
          success: false
        }),
      };
    }

    // Test with direct HTTP request to Google AI API
    try {
      console.log('🟠 Testing direct HTTP request to Google AI API...');
      
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${apiKey}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [{
            parts: [{
              text: 'Merhaba, nasılsın?'
            }]
          }]
        })
      });

      console.log('Response status:', response.status);
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error('API Error:', errorText);
        
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({
            message: 'Google AI API Error',
            status: response.status,
            error: errorText,
            success: false
          }),
        };
      }

      const data = await response.json();
      console.log('API Response:', data);
      
      if (data.candidates && data.candidates[0] && data.candidates[0].content) {
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({
            message: 'Google AI API Success!',
            response: data.candidates[0].content.parts[0].text,
            success: true
          }),
        };
      } else {
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({
            message: 'Unexpected API response format',
            data: data,
            success: false
          }),
        };
      }

    } catch (fetchError) {
      console.error('Fetch error:', fetchError);
      
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          message: 'Fetch error',
          error: fetchError.message,
          success: false
        }),
      };
    }

  } catch (error) {
    console.error('Function error:', error);
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        message: 'Function error',
        error: error.message,
        success: false
      }),
    };
  }
};